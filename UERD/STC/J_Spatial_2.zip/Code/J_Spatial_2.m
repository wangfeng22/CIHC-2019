function S_STRUCT = J_Spatial_2(coverPath, payload)

C_STRUCT = jpeg_read(coverPath);
QUANT=C_STRUCT.quant_tables{1};
C_COEFFS = C_STRUCT.coef_arrays{1};
nzAC = nnz(C_COEFFS)-nnz(C_COEFFS(1:8:end,1:8:end));
hidden_message=double(rand(1,round(payload * nzAC))<0.5);
[k,l] = size(C_COEFFS);
costP=zeros(k,l);
costM=zeros(k,l);
%--------------------
hpdf = [-0.0544158422, 0.3128715909, -0.6756307363, 0.5853546837, 0.0158291053, -0.2840155430, -0.0004724846, 0.1287474266, 0.0173693010, -0.0440882539, ...
        -0.0139810279, 0.0087460940, 0.0048703530, -0.0003917404, -0.0006754494, -0.0001174768];
lpdf = (-1).^(0:numel(hpdf)-1).*fliplr(hpdf);
F{1} = lpdf'*hpdf;
F{2} = hpdf'*lpdf;
F{3} = hpdf'*hpdf;
fun = @(x)x.data .*C_STRUCT.quant_tables{1};
I_spatial = blockproc(C_COEFFS,[8 8],fun);
fun=@(x)idct2(x.data);
I_spatial = blockproc(I_spatial,[8 8],fun)+128;
blockR=zeros(k,l);
for i=1:3
    R=conv2(I_spatial,F{i},'same');
    blockR=blockR+abs(R);
end
block=zeros(k,l);
for i=1:8:k
    for j=1:8:l
        temp=abs(blockR(i:i+7,j:j+7));
        block(i:i+7,j:j+7)=sum(temp(:));
    end
end
sub=block(1:8:end,1:8:end);
subdiff=prediction(sub);
blockdiff=zeros(k,l);
u=1;v=1;
for i=1:8:k
    for j=1:8:l
        blockdiff(i:i+7,j:j+7)=abs(subdiff(u,v));
        v=v+1;
    end
    u=u+1;v=1;
end
for i=1:8:k
    for j=1:8:l
        costP(i:i+7,j:j+7)=QUANT;
        costM(i:i+7,j:j+7)=QUANT;
    end
end
costP=costP./(block+blockdiff);
costM=costM./(block+blockdiff);
costP=costP/min(costP(:));
costM=costM/min(costM(:));
wetConst=10^13;
costP(isnan(costP)) = wetConst;
costM(isnan(costM)) = wetConst;
costP(costP > wetConst) = wetConst;
costM(costM > wetConst) = wetConst;
costP(C_COEFFS > 1023) = wetConst;
costM(C_COEFFS < -1023) = wetConst;

cover=C_COEFFS(:);
costs=zeros(3,k*l,'single');
costs(1,:)=costM(:);
costs(3,:)=costP(:);
%% --------------------------- ��ϢǶ�� ------------------------------------
[~,stego,~,~] = stc_pm1_pls_embed(int32(cover)',costs,uint8(hidden_message),10);%��ϢǶ��
% extr_msg = stc_ml_extract(stego, n_msg_bits,10);%��Ϣ��ȡ
% error=sum(hidden_message~=double(extr_msg));%��֤��Ϣ�Ƿ���ȷǶ��
S_STRUCT = C_STRUCT;
stego=reshape(stego,[k l]);
stego=double(stego);
S_STRUCT.coef_arrays{1} = stego;
end

function plane=prediction(X)
[k,l] = size(X);
plane=zeros(k,l);
for i=1:k
    for j=1:l
        if i-1>0 && i+1<=k && j-1>0 && j+1<=l
            plane(i,j)=(X(i,j-1)+X(i,j+1)+X(i-1,j)+X(i+1,j))/4;
        elseif i-1>0 && i+1<=k && j-1>0
            plane(i,j)=(X(i,j-1)+X(i-1,j)+X(i+1,j))/3;
        elseif i-1>0 && i+1<=k && j+1<=l
            plane(i,j)=(X(i,j+1)+X(i-1,j)+X(i+1,j))/3;
        elseif i-1>0 && j-1>0 && j+1<=l
            plane(i,j)=(X(i,j-1)+X(i,j+1)+X(i-1,j))/3;
        elseif i+1<=k && j-1>0 && j+1<=l
            plane(i,j)=(X(i,j-1)+X(i,j+1)+X(i+1,j))/3;
        elseif i+1<=k && j+1<=l
            plane(i,j)=(X(i,j+1)+X(i+1,j))/2;
        elseif i+1<=k && j-1>0
            plane(i,j)=(X(i+1,j)+X(i,j-1))/2;
        elseif i-1>0 && j+1<=l
            plane(i,j)=(X(i,j+1)+X(i-1,j))/2;
        else
            plane(i,j)=(X(i,j-1)+X(i-1,j))/2;
        end
    end
end
end